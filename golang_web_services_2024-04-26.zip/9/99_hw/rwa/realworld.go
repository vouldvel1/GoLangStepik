package main

import (
	"net/http"
)

// сюда писать код

func GetApp() http.Handler {
	return nil
}
