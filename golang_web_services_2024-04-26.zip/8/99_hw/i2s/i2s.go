package main

/*
func i2s(data interface{}, out interface{}) error {
	// todo
}
*/
