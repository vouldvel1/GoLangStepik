package main

func main() {
	println("usage: make test")
}
