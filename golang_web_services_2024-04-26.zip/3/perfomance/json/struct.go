package main

//easyjson:json
type User struct {
	Id       int
	RealName string
	Login    string
	Flags    int
	Status   int
}

type Client struct {
	Id       int
	RealName string
	Login    string
	Flags    int
	Status   int
}
